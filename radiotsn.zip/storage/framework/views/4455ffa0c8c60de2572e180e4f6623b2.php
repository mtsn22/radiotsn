<footer class="bg-white border-b border-gray-100 flex items-center justify-center p-2 sticky bottom-0 h-40 shadow-inherit">
   
            <audio controls src="https://Fps3.listen2myradio.com:2199/listen.php?ip=109.169.23.124&amp;port=9404&amp;type=s1"></audio>
        
     
</footer>
<?php /**PATH C:\laragon\www\radiotsn\resources\views/layouts/navigation-bottom.blade.php ENDPATH**/ ?>