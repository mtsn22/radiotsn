<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans antialiased">
       <nav  class="sticky top-0">
        <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       </nav>
        <div class="min-h-screen justify-center bg-gray-100">
            <!-- Page Content -->
            <main class="flex items-center justify-center sticky top-20">
                    <div class="card card-compact w-72 bg-base-100 shadow-xl">
                        <?php $__currentLoopData = $siarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siarans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <figure><img src="<?php echo e(asset('storage/'.$siarans->poster)); ?>" alt="SS-siaran" /></figure>
                        <div class="card-body">
                        <p><?php echo e($siarans->judul); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
            </main>
            
        </div>
       
        <footer class="sticky bottom-0">
            <?php echo $__env->make('layouts.navigation-bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </footer>
    </body>
</html>
<?php /**PATH C:\laragon\www\radiotsn\resources\views/welcome.blade.php ENDPATH**/ ?>