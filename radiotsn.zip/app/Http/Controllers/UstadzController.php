<?php

namespace App\Http\Controllers;

use App\Models\Ustadz;
use App\Http\Requests\StoreUstadzRequest;
use App\Http\Requests\UpdateUstadzRequest;

class UstadzController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreUstadzRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Ustadz $ustadz)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Ustadz $ustadz)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateUstadzRequest $request, Ustadz $ustadz)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Ustadz $ustadz)
    {
        //
    }
}
