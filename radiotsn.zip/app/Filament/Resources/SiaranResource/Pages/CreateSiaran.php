<?php

namespace App\Filament\Resources\SiaranResource\Pages;

use App\Filament\Resources\SiaranResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSiaran extends CreateRecord
{
    protected static string $resource = SiaranResource::class;
}
